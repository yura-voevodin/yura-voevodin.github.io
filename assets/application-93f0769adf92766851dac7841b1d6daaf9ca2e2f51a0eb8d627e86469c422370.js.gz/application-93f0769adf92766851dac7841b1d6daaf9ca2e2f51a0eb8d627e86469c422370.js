// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import * as jquery from 'jquery'
import * as bootstrap from "bootstrap";
